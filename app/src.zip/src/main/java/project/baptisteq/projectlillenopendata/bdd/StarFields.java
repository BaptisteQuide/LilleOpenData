package project.baptisteq.projectlillenopendata.bdd;


import org.greenrobot.greendao.annotation.Entity;

/**
 * Représente un Fields mis en favori
 * Pas de relation, l'objet est atomique
 * On stocke un ID auto généré et un recordID unique afin de le matcher avec les données OPEN DATA
 */

@Entity(
        // If you have more than one schema, you can tell greenDAO
        // to which schema an entity belongs (pick any string as a name).
        //schema = "myschema",

        // Flag to make an entity "active": Active entities have update,
        // delete, and refresh methods.
        active = true,

        // Specifies the name of the table in the database.
        // By default, the name is based on the entities class name.
        //nameInDb = "AWESOME_USERS",

        // Define indexes spanning multiple columns here.
        //indexes = {
        //      @Index(value = "name DESC", unique = true)
        //},

        // Flag if the DAO should create the database table (default is true).
        // Set this to false, if you have multiple entities mapping to one table,
        // or the table creation is done outside of greenDAO.
        //createInDb = false,

        // Whether an all properties constructor should be generated.
        // A no-args constructor is always required.
        //generateConstructors = true,

        // Whether getters and setters for properties should be generated if missing.
        generateGettersSetters = true
)
public class StarFields {

    private Long id;
    private String recordId;


}

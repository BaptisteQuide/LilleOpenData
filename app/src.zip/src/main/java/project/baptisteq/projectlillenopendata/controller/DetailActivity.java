package project.baptisteq.projectlillenopendata.controller;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import project.baptisteq.projectlillenopendata.R;
import project.baptisteq.projectlillenopendata.beans.Fields;
import project.baptisteq.projectlillenopendata.fragment.FieldsDetail;
import project.baptisteq.projectlillenopendata.fragment.MapsDetail;

public class DetailActivity extends AppCompatActivity {


    /**
     * Clé de chargement du Fields lu
     */
    public static final String KEY_FIELDS_DETAIL = "KEY_FIELDS_DETAIL";

    private static final String KEY_FRAG_MAPDETAILS = "FRAG_MAPDETAILS";
    private static final String KEY_FRAG_FIELDSDETAILS = "FRAG_FIELDSDETAILS";


    private Fields fields;
    private TextView tvToolbarTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = this.getIntent();

        if (savedInstanceState != null)
            fields = (Fields) savedInstanceState.getParcelable(KEY_FIELDS_DETAIL);
        else
            fields = (Fields) intent.getExtras().getSerializable(KEY_FIELDS_DETAIL);

        setUpToolbar();

        /**
         * Création des fragments
         */
        createFragments(intent, savedInstanceState);
    }

    private void setUpToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        TextView tvToolbarTitle = (TextView) toolbar.findViewById(R.id.toolbar_title);
        tvToolbarTitle.setText(fields.getNom());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putParcelable(KEY_FIELDS_DETAIL, fields);
    }
    /**
     * Création des fraguments
     * On remplace les FrameLayout afin de passer des arguments en paramètres
     *
     * @param intent
     * @param savedInstanceState
     */
    private void createFragments(Intent intent, Bundle savedInstanceState) {
        MapsDetail mapsDetailFragment = new MapsDetail();
        mapsDetailFragment.setArguments(intent.getExtras());

        FieldsDetail fieldsDetailFragment = new FieldsDetail();
        fieldsDetailFragment.setArguments(intent.getExtras());


        /**
         * Protection lors de la création des fragments
         * En effet, lors d'une rotation d'écran, certains comportements peuvent être innatendus
         */
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().add(R.id.flMapsDetail, mapsDetailFragment, KEY_FRAG_MAPDETAILS).add(R.id.flFieldsDetail, fieldsDetailFragment, KEY_FRAG_FIELDSDETAILS).commit();
        } else {

        }
    }
}

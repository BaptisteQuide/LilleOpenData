
package project.baptisteq.projectlillenopendata.beans;


public class Parameters {


}

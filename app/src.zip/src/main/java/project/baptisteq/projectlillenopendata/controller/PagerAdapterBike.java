package project.baptisteq.projectlillenopendata.controller;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.Arrays;
import java.util.List;

import project.baptisteq.projectlillenopendata.fragment.BikeList;
import project.baptisteq.projectlillenopendata.fragment.MapsGlobal;

/**
 * Created by Baptiste on 20/05/18.
 */

public class PagerAdapterBike extends FragmentPagerAdapter {


    List<Fragment> fragments = Arrays.asList(new MapsGlobal(), new BikeList(), new Fragment());


    public PagerAdapterBike(FragmentManager supportFragmentManager) {
        super(supportFragmentManager);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }


    @Override
    public int getCount() {
        return fragments.size();
    }

}
